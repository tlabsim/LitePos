// app/loader.js - HTML Component Loader (Works without server)
(function() {
    'use strict';
    
    window.LitePos = window.LitePos || {};
    const ns = window.LitePos;
    
    // Component loader
    ns.loadComponent = async function(path, targetId) {
        try {
            const response = await fetch(path);
            if (!response.ok) {
                throw new Error(`Failed to load ${path}: ${response.statusText}`);
            }
            const html = await response.text();
            
            const target = document.getElementById(targetId);
            if (target) {
                target.innerHTML = html;
            } else {
                console.error(`Target element #${targetId} not found`);
            }
            
            return html;
        } catch (error) {
            console.error(`Error loading component from ${path}:`, error);
            
            // Fallback: If fetch fails (file:// protocol on some browsers),
            // try using XMLHttpRequest
            return loadComponentFallback(path, targetId);
        }
    };
    
    // Fallback loader using XMLHttpRequest (works better with file:// on some browsers)
    function loadComponentFallback(path, targetId) {
        return new Promise((resolve, reject) => {
            const xhr = new XMLHttpRequest();
            xhr.open('GET', path, true);
            xhr.onreadystatechange = function() {
                if (xhr.readyState === 4) {
                    if (xhr.status === 200 || xhr.status === 0) { // 0 for file://
                        const target = document.getElementById(targetId);
                        if (target) {
                            target.innerHTML = xhr.responseText;
                        }
                        resolve(xhr.responseText);
                    } else {
                        reject(new Error(`Failed to load ${path}`));
                    }
                }
            };
            xhr.send();
        });
    }
    
    // Load multiple components in parallel
    ns.loadComponents = async function(components) {
        const promises = components.map(({ path, targetId }) => 
            ns.loadComponent(path, targetId)
        );
        return Promise.all(promises);
    };
    
    // Initialize app - load all views
    ns.initializeApp = async function() {
        console.log('[Loader] Initializing LitePos...');
        
        // Load structural components first
        await ns.loadComponents([
            { path: 'components/sidebar.html', targetId: 'sidebar-container' },
            { path: 'components/modals.html', targetId: 'modals-container' }
        ]);
        
        // Load all tab views (hidden initially)
        await ns.loadComponents([
            { path: 'views/pos.html', targetId: 'view-pos' },
            { path: 'views/products.html', targetId: 'view-products' },
            { path: 'views/sales.html', targetId: 'view-sales' },
            { path: 'views/customers.html', targetId: 'view-customers' },
            { path: 'views/reports.html', targetId: 'view-reports' },
            { path: 'views/admin.html', targetId: 'view-admin' }
        ]);
        
        console.log('[Loader] All components loaded');
        
        // Initialize the app after all views are loaded
        if (typeof window.init === 'function') {
            window.init();
        }
    };
    
    // Tab switching
    ns.switchTab = function(tabName) {
        // Hide all views
        const views = document.querySelectorAll('.tab-view');
        views.forEach(view => view.classList.remove('active'));
        
        // Show selected view
        const targetView = document.getElementById(`view-${tabName}`);
        if (targetView) {
            targetView.classList.add('active');
        }
        
        // Update sidebar active state
        const navItems = document.querySelectorAll('.sidebar-nav-item');
        navItems.forEach(item => item.classList.remove('active'));
        
        const activeItem = document.querySelector(`[data-tab="${tabName}"]`);
        if (activeItem) {
            activeItem.classList.add('active');
        }
        
        // Store current tab
        localStorage.setItem('litepos_current_tab', tabName);
        
        // Trigger tab-specific initialization
        if (ns.onTabSwitch && typeof ns.onTabSwitch === 'function') {
            ns.onTabSwitch(tabName);
        }
    };
    
    // Theme toggle
    ns.toggleTheme = function() {
        const body = document.body;
        const currentTheme = body.getAttribute('data-theme') || 'light';
        const newTheme = currentTheme === 'light' ? 'dark' : 'light';
        
        body.setAttribute('data-theme', newTheme);
        localStorage.setItem('litepos_theme', newTheme);
        
        console.log(`[Theme] Switched to ${newTheme} mode`);
    };
    
    // Apply saved theme on load
    ns.applySavedTheme = function() {
        const savedTheme = localStorage.getItem('litepos_theme') || 'light';
        document.body.setAttribute('data-theme', savedTheme);
    };
    
    // Restore last active tab
    ns.restoreLastTab = function() {
        const lastTab = localStorage.getItem('litepos_current_tab') || 'pos';
        ns.switchTab(lastTab);
    };
    
})();
